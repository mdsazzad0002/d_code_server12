---
title: Resources and alternatives
weight: 8
---

Under the hood this package makes uses of the excellent [league/commonmark](https://commonmark.thephpleague.com) package.

If you don't want to install and handle all the dependencies of this package yourself, take a look at [Torchlight](https://torchlight.dev), which can highlight your code with minimal setup.
